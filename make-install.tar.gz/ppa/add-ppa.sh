#!/bin/bash

# Atom-hackable text editor
sudo add-apt-repository ppa:webupd8team/atom -y

# chromium-browser
sudo add-apt-repository ppa:saiarcot895/chromium-dev -y

# geary-team
sudo add-apt-repository ppa:geary-team/releases -y

# Minitube
sudo add-apt-repository ppa:nilarimogard/webupd8 -y

# Neofetch
sudo add-apt-repository ppa:dawidd0811/neofetch -y

# Skype
sudo add-apt-repository ppa:andykimpe/skype -y

# Tomhack
sudo add-apt-repository ppa:tomahawk/ppa -y

# Unity-tweak-tool
sudo add-apt-repository ppa:tribaal/unity-tweak-tool -y

# vlc
sudo add-apt-repository ppa:n-muench/vlc2 -y
