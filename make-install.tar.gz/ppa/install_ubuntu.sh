# Atom-hackable text editor
sudo apt-get install atom -y

# chromium-browser
sudo apt-get install chromium-browser -y

# geary-team
sudo apt-get install geary -y

# Minitube
sudo apt-get install minitube -y

# Neofetch
sudo apt-get install neofetch -y

# Skype
sudo apt-get install skype -y

# Tomhack
sudo apt-get install tomahawk -y

# Unity-tweak-tool
sudo apt-get install unity-tweak-tool -y

# vlc
sudo apt-get install vlc -y
